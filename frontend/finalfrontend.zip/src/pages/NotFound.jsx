import React from 'react'

export const NotFound = () => {
  return (
    <>
        <h1>404 Not Found</h1>
        <p>The Page you're looking for doesn't exist!</p>
    </>
  )
}
