import React from 'react'
import Form from '../components/Form';
// import { Navigate } from 'react-router-dom';

export const Login = () => {
  return (
    <Form route="/api/token/" method="login" />
    // <button onClick={()= Navigate('/')}/>
  )
}