import React, { useEffect, useState } from "react";
import api from "../api"; 
import "../styles/home.css"


export const Home = () => {
    const [students, setStudents] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    // useEffect hook runs once when the component mounts to fetch student data
    useEffect(() => {
        const fetchStudents = async () => {
            try {
                const response = await api.get("/api/students/");  // your API endpoint
                setStudents(response.data);
            } catch (error) {
                setError("Failed to load student data");
            } finally {
                setLoading(false);
            }
        };

        fetchStudents();
    }, []);

    if (loading) {
        return <div>Loading...</div>;
    }

    if (error) {
        return <div>{error}</div>;
    }

    return (
        <div className="home-container">
            <h1>Student Details</h1>
            {students.length === 0 ? (
                <p>No students found.</p>
            ) : (
                <table className="student-table">
                    <thead>
                        <tr>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Date of Birth</th>
                            <th>Blood Group</th>
                            <th>Department</th>
                            <th>City</th>
                        </tr>
                    </thead>
                    <tbody>
                        {students.map((student, index) => (
                            <tr key={index}>
                                <td>{student.first_name}</td>
                                <td>{student.last_name}</td>
                                <td>{student.dob}</td>
                                <td>{student.blood_group}</td>
                                <td>{student.department}</td>
                                <td>{student.city}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}
        </div>
    );
};


